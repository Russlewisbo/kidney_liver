"""Preview of Bland-Altman figure for CrCl estimation in ICU."""
import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(2026)
n = 150
measured = np.maximum(5, rng.normal(95, 55, n))
bias_sys = 25 - 0.35 * measured
noise = rng.normal(0, 18, n)
estimated = np.maximum(5, measured + bias_sys + noise)

mean_cl = (measured + estimated) / 2
diff = estimated - measured
mean_diff = diff.mean()
sd_diff = diff.std(ddof=1)
loa_low = mean_diff - 1.96 * sd_diff
loa_high = mean_diff + 1.96 * sd_diff

fig, ax = plt.subplots(figsize=(10, 5.5), dpi=200)
xlim = (0, max(260, mean_cl.max() + 10))

ax.axvspan(130, xlim[1], color="#fde7e7", alpha=0.6, zorder=0)
ax.text(132, 75, "Augmented renal\nclearance zone",
        color="#a83232", fontsize=11.5, va="top", ha="left")

ax.axhline(0, color="grey", lw=1)
ax.axhline(mean_diff, color="#1f77b4", lw=1.8)
ax.axhline(loa_high, color="#1f77b4", lw=1.2, ls="--")
ax.axhline(loa_low, color="#1f77b4", lw=1.2, ls="--")

ax.scatter(mean_cl, diff, alpha=0.55, s=45, color="#333333", edgecolor="none")

ax.text(5, mean_diff + 4, f"Bias = {mean_diff:+.1f} mL/min",
        color="#1f77b4", fontsize=11.5, fontweight="bold")
ax.text(5, loa_high - 5, f"Upper LoA = {loa_high:+.1f}",
        color="#1f77b4", fontsize=10.5)
ax.text(5, loa_low + 5, f"Lower LoA = {loa_low:.1f}",
        color="#1f77b4", fontsize=10.5)

ax.set_xlim(xlim)
ax.set_xlabel("Mean of estimated and measured CrCl (mL/min)",
              fontweight="bold", fontsize=13)
ax.set_ylabel("Cockcroft-Gault − measured CrCl (mL/min)",
              fontweight="bold", fontsize=13)
ax.grid(True, alpha=0.3)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
plt.tight_layout()
plt.savefig("figures/bland_altman_crcl.png", bbox_inches="tight", facecolor="white")
print("Saved figures/bland_altman_crcl.png")
