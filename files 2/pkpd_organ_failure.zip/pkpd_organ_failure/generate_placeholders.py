"""
Generate clean placeholder figures for the slides whose visuals you'll source
later (prevalence chart, DALI scatter, PK/PD indices, etc.). Each placeholder
shows the slide's figure intent so the deck renders cleanly during draft.
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

placeholders = {
    "prevalence_placeholder.png":
        "Figure to source:\nPrevalence of AKI / cirrhosis among\nseptic ICU and hematologic patients",
    "empirical_dosing_placeholder.png":
        "Figure to source:\nDALI-style scatter — measured\nβ-lactam fT>MIC vs label-recommended dose",
    "pkpd_indices_placeholder.png":
        "Figure to source:\nConcentration-time curve annotated with\nCmax/MIC · fAUC/MIC · fT>MIC",
    "free_drug_placeholder.png":
        "Figure to source:\nFree vs bound drug schematic\nat site of infection (ELF, tissue)",
    "halflife_vs_crcl_placeholder.png":
        "Figure to source:\nHalf-life vs CrCl curves overlaid\nfor meropenem · vancomycin · daptomycin · colistin",
    "arc_histogram_placeholder.png":
        "Figure to source:\nMeasured CrCl distribution in septic ICU\nwith ARC zone shaded + PTA inset",
    "crrt_schematic_placeholder.png":
        "Figure to source:\nCVVH vs CVVHDF circuit schematic\nwith CL_CRRT = Q_eff × S_c overlay",
    "loading_dose_placeholder.png":
        "Figure to source:\nSimulated concentration-time curves —\nfull vs reduced loading dose, PD target line",
    "cirrhosis_2x2_placeholder.png":
        "Figure to source:\n2×2 grid of cirrhosis PK mechanisms\nwith example drugs in each quadrant",
    "child_pugh_pk_placeholder.png":
        "Figure to source:\nClearance vs Child-Pugh score scatter\nfor voriconazole / tigecycline / moxifloxacin",
    "hrs_placeholder.png":
        "Figure to source:\nPaired bars — measured GFR vs serum\ncreatinine in HRS, at-risk drug callout",
    "protein_binding_placeholder.png":
        "Figure to source:\nTwo panels — free fraction vs albumin (rising);\nclearance vs albumin (rising); net effect on free AUC",
    "total_vs_free_placeholder.png":
        "Figure to source:\nSide-by-side concentration-time curves —\ntotal therapeutic, free sub-target",
    "mipd_workflow_placeholder.png":
        "Figure to source:\nMIPD workflow — concentration in →\nposterior PK → recommended next dose",
}

for fname, text in placeholders.items():
    fig, ax = plt.subplots(figsize=(10, 5.5), dpi=140)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.axis("off")
    box = FancyBboxPatch((0.03, 0.08), 0.94, 0.84,
                         boxstyle="round,pad=0.01,rounding_size=0.015",
                         linewidth=2, edgecolor="#1f3a5f",
                         facecolor="#f7f9fc", linestyle="--")
    ax.add_patch(box)
    ax.text(0.5, 0.5, text, ha="center", va="center",
            fontsize=15, color="#1f3a5f", fontweight="500",
            family="sans-serif")
    ax.text(0.5, 0.96, "[ Placeholder ]", ha="center", va="top",
            fontsize=10, color="#7a7a7a", style="italic")
    plt.savefig(f"figures/{fname}", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"Saved figures/{fname}")
