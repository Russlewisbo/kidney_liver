# PK/PD of antimicrobials in liver and kidney failure — 30-min AE talk

Assertion-evidence (Alley) Quarto RevealJS deck.

## Files

```
pkpd_organ_failure/
├── pkpd_organ_failure.qmd      ← main deck (19 content slides + dividers)
├── pkpd_organ_failure.html     ← pre-rendered deck (open in any browser)
├── custom.scss                 ← AE theme overrides
├── _quarto.yml
├── R/                          ← production figure scripts
│   ├── 01_pta_meropenem.R          Monte Carlo PTA: intermittent / extended / continuous
│   ├── 02_bland_altman_crcl.R      CG vs measured CrCl with ARC zone
│   └── 03_decision_algorithm.R     DiagrammeR/Graphviz decision tree
├── figures/
│   ├── pta_meropenem.png           [Python preview — re-render in R for production]
│   ├── bland_altman_crcl.png       [Python preview — re-render in R for production]
│   ├── decision_algorithm.png      [Graphviz, production-quality]
│   ├── decision_algorithm.dot      Standalone Graphviz source
│   └── *_placeholder.png           Slots for figures you'll source/draw
├── preview_pta.py              ← Python preview generator (delete after R run)
├── preview_bland_altman.py     ← Python preview generator (delete after R run)
└── generate_placeholders.py    ← placeholder generator
```

## Quick start

Open `pkpd_organ_failure.html` in a browser to see the deck as it stands. Press
`S` for speaker notes view, `?` for keybindings.

## To produce the production figures in R

```r
# from project root
source("R/01_pta_meropenem.R")
source("R/02_bland_altman_crcl.R")
source("R/03_decision_algorithm.R")
```

Required packages: `dplyr`, `tidyr`, `ggplot2`, `scales`, `DiagrammeR`,
`DiagrammeRsvg`, `rsvg`. The R scripts produce PNGs at the same paths as the
Python previews, so once you re-run them the deck picks them up automatically.

## To re-render the deck

```bash
quarto render pkpd_organ_failure.qmd
```

For PDF export from the running deck: press `E` in browser to switch to
print mode, then print → save as PDF.

## Slide structure (assertion-evidence)

Each content slide is **one full-sentence headline** + **one supporting
visual**. No bullet lists in the body. Speaker notes (in `::: notes` blocks)
carry the prose argument; press `S` in the browser to open the speaker view.

| §        | Slides | Time   |
|----------|--------|--------|
| Framing  | 3      | ~4 min |
| Framework| 2      | ~3 min |
| Kidney   | 5      | ~8 min |
| Liver    | 3      | ~5 min |
| Protein  | 2      | ~3 min |
| Optimize | 3      | ~5 min |
| Close    | 1      | ~2 min |

## Placeholder figures still to source

These have `_placeholder.png` dashed-box placeholders so the deck renders:

- prevalence_placeholder — organ-failure prevalence (e.g., KDIGO + EASL-CLIF data)
- empirical_dosing_placeholder — DALI scatter or Roberts/Lipman summary
- pkpd_indices_placeholder — Craig triptych (Cmax/MIC, fAUC/MIC, fT>MIC)
- free_drug_placeholder — free vs bound at site of infection
- halflife_vs_crcl_placeholder — half-life vs CrCl overlay
- arc_histogram_placeholder — measured CrCl distribution in septic ICU
- crrt_schematic_placeholder — CVVH / CVVHDF circuit + S_c equation
- loading_dose_placeholder — full vs reduced loading dose simulation
- cirrhosis_2x2_placeholder — four cirrhosis PK mechanisms
- child_pugh_pk_placeholder — clearance vs Child-Pugh scatter
- hrs_placeholder — measured GFR vs serum creatinine in HRS
- protein_binding_placeholder — two-panel albumin / clearance plot
- total_vs_free_placeholder — total vs free conc-time curves
- mipd_workflow_placeholder — MIPD workflow schematic

Several of these (loading dose, half-life vs CrCl, protein binding, total vs
free) can be generated with the same one-compartment PK code in
`R/01_pta_meropenem.R`. Happy to draft them as a second pass.
