"""
Preview render of the Monte Carlo PTA figure (matches R script aesthetics).
Replace with R output for production.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

rng = np.random.default_rng(42)
n_subj = 5000

# Population PK parameters
CL_tv, V_tv = 12.0, 25.0  # L/h, L
CV_CL, CV_V = 0.45, 0.30

CL = CL_tv * np.exp(rng.normal(0, CV_CL, n_subj))
V  = V_tv  * np.exp(rng.normal(0, CV_V,  n_subj))
ke = CL / V

mic_grid = np.array([0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32])
t_grid = np.arange(0, 24.0001, 0.05)


def conc_intermittent(t, CL, V, dose, tinf, tau, n_doses=4):
    k = CL / V
    R0 = dose / tinf
    C = np.zeros_like(t)
    for n in range(n_doses):
        t0 = n * tau
        t_end = t0 + tinf
        in_inf = (t >= t0) & (t <= t_end)
        C[in_inf] += (R0 / CL) * (1 - np.exp(-k * (t[in_inf] - t0)))
        post = t > t_end
        Cend = (R0 / CL) * (1 - np.exp(-k * tinf))
        C[post] += Cend * np.exp(-k * (t[post] - t_end))
    return C


def conc_continuous(t, CL, V, load_dose, load_tinf, cont_rate):
    k = CL / V
    C = np.zeros_like(t)
    R0 = load_dose / load_tinf
    in_load = t <= load_tinf
    C[in_load] = (R0 / CL) * (1 - np.exp(-k * t[in_load]))
    Cend = (R0 / CL) * (1 - np.exp(-k * load_tinf))
    post = t > load_tinf
    tt = t[post] - load_tinf
    Css = cont_rate / CL
    C[post] = Cend * np.exp(-k * tt) + Css * (1 - np.exp(-k * tt))
    return C


def pta_for_regimen(regimen):
    pta = []
    for mic in mic_grid:
        hits = 0
        for i in range(n_subj):
            if regimen == "intermittent":
                C = conc_intermittent(t_grid, CL[i], V[i], dose=1000, tinf=0.5, tau=8)
                eval_mask = t_grid >= 16
            elif regimen == "extended":
                C = conc_intermittent(t_grid, CL[i], V[i], dose=1000, tinf=3.0, tau=8)
                eval_mask = t_grid >= 16
            else:
                C = conc_continuous(t_grid, CL[i], V[i],
                                    load_dose=1000, load_tinf=0.5,
                                    cont_rate=3000/24)
                eval_mask = t_grid >= 12
            f = np.mean(C[eval_mask] > mic)
            if f >= 0.5:
                hits += 1
        pta.append(hits / n_subj)
    return np.array(pta)


regimens = [
    ("Intermittent (0.5 h)", "#7f7f7f", "intermittent"),
    ("Extended (3 h)",       "#1f77b4", "extended"),
    ("Continuous (24 h)",    "#d62728", "continuous"),
]

fig, ax = plt.subplots(figsize=(10, 5.5), dpi=200)
ax.axhline(0.9, ls="--", color="grey", lw=1)
ax.text(0.15, 0.93, "90% PTA target", color="#666666", fontsize=11, va="bottom")

for label, color, key in regimens:
    pta = pta_for_regimen(key)
    ax.plot(mic_grid, pta, "-o", color=color, lw=2.2, ms=6, label=label)

ax.set_xscale("log")
ax.set_xticks(mic_grid)
ax.set_xticklabels([str(x) for x in mic_grid])
ax.set_xlabel("MIC (mg/L)", fontweight="bold", fontsize=13)
ax.set_ylabel("Probability of attaining 50% fT>MIC", fontweight="bold", fontsize=13)
ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
ax.set_ylim(0, 1.0)
ax.grid(True, which="major", alpha=0.3)
ax.legend(loc="upper right", frameon=True, fontsize=11)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()
plt.savefig("figures/pta_meropenem.png", bbox_inches="tight", facecolor="white")
print("Saved figures/pta_meropenem.png")
